class student:
    def __init__(self, student_id, student_name, student_group):
        if type(student_id) != int and type(student_id) != float:
            raise ValueError("Incorect id!")
        if type(student_name) != str:
            raise ValueError("Incorect name!")
        if type(student_group) != int and type(student_group) != float and int(student_group) <0:
            raise ValueError("Incorect group!")

        self.__stud_id = student_id
        self.__stud_name = student_name
        self.__stud_group = student_group



    @property
    def get_id(self):
        return self.__stud_id

    @property
    def get_name(self):
        return self.__stud_name

    @property
    def get_group(self):
        return self.__stud_group

    def __str__(self):
        return "Id: " + str(self.get_id) + ", name: " + str(self.get_name) + ", group: " + str(self.get_group)

