from src.domain.Student import student

class function:
    def __init__(self):
        self.stud_list = []
        self.stack_list = []

    def add_student(self, id, name, group):
        """
        Add a student
        :param id: the student's id
        :param name: the student's name
        :param group: the student's group
        :return: modifies the list by adding a student
        """
        self.stud_list.append(student(id, name, group))
        self.generate_copy()

    def get_student(self):
        return self.stud_list

    def generate_students(self):
        self.stud_list.append(student(345, 'Albu', 911))
        self.stud_list.append(student(567, 'Iancu', 912))
        self.stud_list.append(student(356, 'Barbu', 913))
        self.stud_list.append(student(468, 'Giurgiu', 914))
        self.stud_list.append(student(379, 'Simina', 915))
        self.stud_list.append(student(465, 'Boia', 916))
        self.stud_list.append(student(765, 'Berindei', 917))
        self.stud_list.append(student(986, 'Cenusa', 919))
        self.stud_list.append(student(784, 'Sicoe', 919))
        self.stud_list.append(student(256, 'Pop', 920))
        self.stack_list.append(self.stud_list.copy())

    def delete_students(self, n):
        """
                Delete a student
                :param n: the student's group
                :return: modifies the list by deleting a student
        """
        x = -1
        for students in self.stud_list:
            x = x + 1
            if int(students.get_group) == int(n):
                del self.stud_list[x]
        self.generate_copy()

    def generate_copy(self):
        self.stack_list.append(self.stud_list.copy())

    def delete_history(self):
        if len(self.stack_list) == 0:
            raise ValueError("Nothing to undo")
        else:
            self.stack_list.pop()
            self.stud_list = self.stack_list[len(self.stack_list)-1]



def test_add():
    func = function()
    func.add_student(567, 'Ciama', 911)
    list = func.get_student()
    s = list[0]
    assert int(s.get_id) == 567 and s.get_name == 'Ciama' and int(s.get_group) == 911




def tests():
    test_add()


