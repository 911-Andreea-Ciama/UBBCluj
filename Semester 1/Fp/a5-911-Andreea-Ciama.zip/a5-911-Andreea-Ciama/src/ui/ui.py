from src.services.functions import function, tests

class console:
    def __init__(self):
        self._func = function()

    def _show_menu(self):
        print("1. Add a student.")
        print("2. Display the list of students.")
        print("3. Delete students from a group")
        print("4. Undo")
        print("5. Exit")


    def get_val(self):
        id = int(input('id: '))
        name = input('name: ')
        group = int(input('group: '))
        self._func.add_student(id, name, group)
        print('Added succesfully')

    def generate_students(self):
        self._func.generate_students()


    def all_students(self):
        s = self._func.get_student()
        for i in s:
            print(str(i))


    def delete(self):
        y = input("Group: ")
        self._func.delete_students(y)
        print("Succesfully deleted")


    def undo(self):
        self._func.delete_history()

    def start(self):
        self.generate_students()
        tests()
        while True:
            self._show_menu()
            opt = input("Choose an option: ")
            if opt == '1':
                self.get_val()
            elif opt == '2':
                self.all_students()
            elif opt == '3':
                self.delete()
            elif opt == '4':
                self.undo()
            elif opt == '5':
                return
            else:
                print("Invalid menu choice")


ui = console()
ui.start()
